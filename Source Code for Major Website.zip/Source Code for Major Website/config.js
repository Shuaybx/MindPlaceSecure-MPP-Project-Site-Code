window.MINDPLACE_CONFIG = window.MINDPLACE_CONFIG || {};

window.MINDPLACE_CONFIG.signalingServer =
  window.MINDPLACE_CONFIG.signalingServer ||
  (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
    ? 'ws://localhost:3000'
    : 'wss://your-signaling-server.example.com');
