/**
 * MindPlaceSecure Encryption Module
 * Uses Web Crypto API (AES-GCM 256) for end-to-end message encryption
 */

// Generate or retrieve a shared encryption key for the room
export async function generateRoomKey() {
  const key = await window.crypto.subtle.generateKey(
    {
      name: 'AES-GCM',
      length: 256
    },
    true, // extractable
    ['encrypt', 'decrypt']
  );
  return key;
}

// Export key to JSON for storage/sharing
export async function exportKeyToJSON(key) {
  const exported = await window.crypto.subtle.exportKey('raw', key);
  return btoa(String.fromCharCode.apply(null, new Uint8Array(exported)));
}

// Import key from JSON
export async function importKeyFromJSON(keyString) {
  const binaryString = atob(keyString);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }

  const key = await window.crypto.subtle.importKey(
    'raw',
    bytes.buffer,
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
  return key;
}

// Encrypt a message
export async function encryptMessage(message, key) {
  const encoder = new TextEncoder();
  const data = encoder.encode(message);

  // Generate random IV (initialization vector)
  const iv = window.crypto.getRandomValues(new Uint8Array(12));

  const encrypted = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: iv
    },
    key,
    data
  );

  // Combine IV + encrypted data and return as base64
  const combined = new Uint8Array(iv.length + encrypted.byteLength);
  combined.set(iv);
  combined.set(new Uint8Array(encrypted), iv.length);

  return btoa(String.fromCharCode.apply(null, combined));
}

// Decrypt a message
export async function decryptMessage(encryptedMessage, key) {
  try {
    const combined = new Uint8Array(
      atob(encryptedMessage)
        .split('')
        .map((c) => c.charCodeAt(0))
    );

    // Extract IV and encrypted data
    const iv = combined.slice(0, 12);
    const encrypted = combined.slice(12);

    const decrypted = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: iv
      },
      key,
      encrypted
    );

    const decoder = new TextDecoder();
    return decoder.decode(decrypted);
  } catch (error) {
    console.error('Decryption error:', error);
    return null;
  }
}
