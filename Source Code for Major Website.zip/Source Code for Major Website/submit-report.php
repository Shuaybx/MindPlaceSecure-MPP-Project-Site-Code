<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON payload']);
    exit;
}

$requiredFields = ['workspace_id', 'subject', 'category', 'encrypted_narrative', 'crypto_hash', 'reporter_pseudonym'];
foreach ($requiredFields as $field) {
    if (empty($input[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Missing field: ' . $field]);
        exit;
    }
}

$host = 'localhost';
$db   = 'mindplace_reports';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}

$reportUuid = uniqid('report_', true);

$sql = "INSERT INTO incident_reports (report_uuid, workspace_id, subject, category, encrypted_narrative, crypto_hash, reporter_pseudonym) VALUES (:report_uuid, :workspace_id, :subject, :category, :encrypted_narrative, :crypto_hash, :reporter_pseudonym)";

$stmt = $pdo->prepare($sql);
try {
    $stmt->execute([
        ':report_uuid' => $reportUuid,
        ':workspace_id' => $input['workspace_id'],
        ':subject' => $input['subject'],
        ':category' => $input['category'],
        ':encrypted_narrative' => $input['encrypted_narrative'],
        ':crypto_hash' => $input['crypto_hash'],
        ':reporter_pseudonym' => $input['reporter_pseudonym'],
    ]);

    echo json_encode(['success' => true, 'message' => 'Report saved to database']);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database insert failed: ' . $e->getMessage()]);
}
