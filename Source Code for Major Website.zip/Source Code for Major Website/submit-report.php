<?php
$reportsFile = __DIR__ . '/reports.json';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON payload']);
    exit;
}

$requiredFields = ['workspace_id', 'subject', 'category', 'encrypted_narrative', 'crypto_hash', 'reporter_pseudonym'];
foreach ($requiredFields as $field) {
    if (empty($input[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Missing field: ' . $field]);
        exit;
    }
}

$reports = [];
if (file_exists($reportsFile)) {
    $existing = file_get_contents($reportsFile);
    $reports = json_decode($existing, true) ?: [];
}

$reports[] = [
    'id' => uniqid('report_', true),
    'created_at' => gmdate('c'),
    'workspace_id' => $input['workspace_id'],
    'subject' => $input['subject'],
    'category' => $input['category'],
    'encrypted_narrative' => $input['encrypted_narrative'],
    'crypto_hash' => $input['crypto_hash'],
    'reporter_pseudonym' => $input['reporter_pseudonym']
];

file_put_contents($reportsFile, json_encode($reports, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

header('Content-Type: application/json');
echo json_encode(['success' => true, 'message' => 'Report saved locally']);
