// theme-manager.js
const ThemeManager = {
  apply() {
    const isHC = localStorage.getItem('highContrast') === 'true';
    const isLarge = localStorage.getItem('largeText') === 'true';
    const isReduced = localStorage.getItem('reducedMotion') === 'true';

    const target = document.body || document.documentElement;
    const root = document.documentElement;

    target.classList.toggle('accessible-high-contrast', isHC);
    target.classList.toggle('accessible-large-text', isLarge);
    target.classList.toggle('accessible-reduced-motion', isReduced);

    root.classList.toggle('accessible-high-contrast', isHC);
    root.classList.toggle('accessible-large-text', isLarge);
    root.classList.toggle('accessible-reduced-motion', isReduced);
  },

  set(key, value) {
    localStorage.setItem(key, value.toString());
    this.apply();
  },

  toggle(key) {
    const currentState = localStorage.getItem(key) === 'true';
    localStorage.setItem(key, (!currentState).toString());
    this.apply();
  },

  get(key) {
    return localStorage.getItem(key) === 'true';
  },

  reset() {
    localStorage.removeItem('highContrast');
    localStorage.removeItem('largeText');
    localStorage.removeItem('reducedMotion');
    this.apply();
  }
};

// Run immediately on page load
ThemeManager.apply();