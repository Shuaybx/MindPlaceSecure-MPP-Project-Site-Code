let currentRoomId = null;
let currentUserName = 'You (Host)'; // Or 'Guest' if joining

// WebRTC Configuration & State
let peerConnection = null;
let dataChannel = null;
const rtcConfig = {
    iceServers: [{ urls: 'stun:stun.l.google.com:1902' }] // Free STUN server to find public IPs
};