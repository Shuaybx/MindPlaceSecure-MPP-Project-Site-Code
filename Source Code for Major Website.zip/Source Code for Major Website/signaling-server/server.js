import express from 'express';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import cors from 'cors';
import { v4 as uuidv4 } from 'uuid';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
const server = createServer(app);
const wss = new WebSocketServer({ server });

// Add runtime error listeners before attempting to listen to avoid uncaught errors
wss.on('error', (err) => {
  console.error('WebSocketServer runtime error (pre-listen):', err);
});

server.on('error', (err) => {
  console.error('HTTP server runtime error (pre-listen):', err);
});

// Room & Peer Management
const rooms = new Map();
const peers = new Map();

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'operational', timestamp: new Date().toISOString() });
});

// Get or create a room
app.post('/api/rooms', (req, res) => {
  const { roomId } = req.body;
  const id = roomId || uuidv4();

  if (!rooms.has(id)) {
    rooms.set(id, {
      id,
      peers: new Set(),
      createdAt: new Date().toISOString(),
      config: {}
    });
  }

  res.json({ roomId: id, status: 'ready' });
});

// Retrieve room metadata
app.get('/api/rooms/:roomId', (req, res) => {
  const { roomId } = req.params;
  const room = rooms.get(roomId);

  if (!room) {
    return res.status(404).json({ error: 'Room not found' });
  }

  res.json({
    roomId: room.id,
    peerCount: room.peers.size,
    createdAt: room.createdAt
  });
});

// WebSocket signaling for PeerJS
wss.on('connection', (ws) => {
  const peerId = uuidv4();
  let assignedRoomId = null;

  peers.set(peerId, { ws, roomId: assignedRoomId });

  ws.on('message', (data) => {
    try {
      const message = JSON.parse(data.toString());
      const { type, roomId, targetPeerId, payload } = message;

      switch (type) {
        case 'join':
          assignedRoomId = roomId;
          peers.get(peerId).roomId = roomId;

          if (!rooms.has(roomId)) {
            rooms.set(roomId, {
              id: roomId,
              peers: new Set(),
              createdAt: new Date().toISOString(),
              config: {}
            });
          }

          const room = rooms.get(roomId);
          room.peers.add(peerId);

          // Notify other peers in the room
          room.peers.forEach((otherId) => {
            if (otherId !== peerId) {
              const otherPeer = peers.get(otherId);
              if (otherPeer && otherPeer.ws.readyState === 1) {
                otherPeer.ws.send(
                  JSON.stringify({
                    type: 'peer-joined',
                    peerId,
                    roomId
                  })
                );
              }
            }
          });

          // Send list of existing peers to the new peer
          const existingPeers = Array.from(room.peers).filter((id) => id !== peerId);
          ws.send(
            JSON.stringify({
              type: 'existing-peers',
              peers: existingPeers,
              roomId
            })
          );

          break;

        case 'signal':
          // Forward signaling data (offer/answer/ice-candidate)
          if (targetPeerId && peers.has(targetPeerId)) {
            const targetPeer = peers.get(targetPeerId);
            if (targetPeer.ws.readyState === 1) {
              targetPeer.ws.send(
                JSON.stringify({
                  type: 'signal',
                  from: peerId,
                  payload
                })
              );
            }
          }
          break;

        case 'leave':
          if (assignedRoomId && rooms.has(assignedRoomId)) {
            const room = rooms.get(assignedRoomId);
            room.peers.delete(peerId);

            // Notify peers that this peer left
            room.peers.forEach((otherId) => {
              const otherPeer = peers.get(otherId);
              if (otherPeer && otherPeer.ws.readyState === 1) {
                otherPeer.ws.send(
                  JSON.stringify({
                    type: 'peer-left',
                    peerId,
                    roomId: assignedRoomId
                  })
                );
              }
            });

            if (room.peers.size === 0) {
              rooms.delete(assignedRoomId);
            }
          }
          break;
      }
    } catch (error) {
      console.error('WebSocket message error:', error);
    }
  });

  ws.on('close', () => {
    if (assignedRoomId && rooms.has(assignedRoomId)) {
      const room = rooms.get(assignedRoomId);
      room.peers.delete(peerId);

      // Notify remaining peers
      room.peers.forEach((otherId) => {
        const otherPeer = peers.get(otherId);
        if (otherPeer && otherPeer.ws.readyState === 1) {
          otherPeer.ws.send(
            JSON.stringify({
              type: 'peer-left',
              peerId,
              roomId: assignedRoomId
            })
          );
        }
      });

      if (room.peers.size === 0) {
        rooms.delete(assignedRoomId);
      }
    }

    peers.delete(peerId);
  });

  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });

  // Send peer ID to newly connected client
  ws.send(JSON.stringify({ type: 'ready', peerId }));
});

// Attempt to bind server, falling back to the next port on EADDRINUSE
async function startServer(preferredPort, maxAttempts = 5) {
  let port = Number(process.env.PORT) || Number(preferredPort) || 3000;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      await new Promise((resolve, reject) => {
        const onError = (err) => {
          server.removeListener('listening', onListening);
          reject(err);
        };

        const onListening = () => {
          server.removeListener('error', onError);
          resolve();
        };

        server.once('error', onError);
        server.once('listening', onListening);
        server.listen(port);
      });

      console.log(`MindPlaceSecure Signaling Server running on port ${port}`);

      // bind WebSocketServer to the listening server (already created with `server`)
      // Ensure we have runtime handlers for errors
      wss.on('error', (err) => {
        console.error('WebSocketServer error:', err);
      });

      server.on('error', (err) => {
        console.error('HTTP server error:', err);
      });

      // expose chosen port to process.env for downstream use
      process.env.PORT = String(port);
      return port;
    } catch (err) {
      if (err && err.code === 'EADDRINUSE') {
        console.warn(`Port ${port} in use, trying ${port + 1} (attempt ${attempt + 1}/${maxAttempts})`);
        port = port + 1;
        // loop to try next port
      } else {
        console.error('Failed to start server:', err);
        process.exit(1);
      }
    }
  }

  console.error(`Unable to bind server after ${maxAttempts} attempts. Exiting.`);
  process.exit(1);
}

// Start the server with fallback behaviour
startServer(PORT).catch((err) => {
  console.error('startServer error:', err);
  process.exit(1);
});
